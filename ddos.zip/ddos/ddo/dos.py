# -*- coding: utf-8 -*-
import requests
from concurrent.futures import ThreadPoolExecutor
import time

def send_request(url):
    response = requests.get(url)
    # 在这里处理响应，例如打印状态码或内容
    print(response.status_code)
    print(response.text)

url = 'https://gis.fdkc.gov.tw/rescue/getnowcase/json?getalls=1'
concurrent_requests = 1000
total_requests = 2000

start_time = time.time()

with ThreadPoolExecutor(max_workers=concurrent_requests) as executor:
    futures = [executor.submit(send_request, url) for _ in range(total_requests)]

# 等待所有请求完成
for future in futures:
    future.result()

end_time = time.time()
execution_time = end_time - start_time
print("总共发送了{}个请求，总耗时：{}秒".format(total_requests, execution_time))
