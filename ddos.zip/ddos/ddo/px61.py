import http.server
import socketserver
import urllib.request

class ProxyHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/tyfdapp/ServletApp?data=78HbV6i6HSJ2j5FIFT01Hg==&cs_no=DOnm6cR8dbj9aq3rvVonGg=='):
            # 构建目标URL
            target_url = 'http://163.29.63.53:8080' + self.path

            # 发起代理请求
            with urllib.request.urlopen(target_url) as response:
                # 获取响应内容
                data = response.read()

                # 将目标服务器的响应返回给浏览器
                self.send_response(response.status)
                self.send_header('Content-type', response.getheader('Content-type'))
                self.end_headers()
                self.wfile.write(data)
        else:
            # 其他路径的请求，返回示例响应
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'Hello, World!')  # 示例响应内容

# 配置代理服务器的IP地址和端口号
proxy_host = '127.0.0.1'  # 本地终端的IP地址
proxy_port = 8081  # 使用的端口号

# 创建代理服务器
with socketserver.TCPServer((proxy_host, proxy_port), ProxyHandler) as httpd:
    print(f'Proxy server is running at {proxy_host}:{proxy_port}')
    httpd.serve_forever() 