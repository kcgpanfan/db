import subprocess
import time
from threading import Timer
from flask import Flask, render_template

app = Flask(__name__)

def run_ab_command():
    # 执行 ab 命令并获取输出
    command = 'ab -n 6000 -c 600 -H "Referer: https://gis.fdkc.gov.tw/rescue" "https://gis.fdkc.gov.tw/rescue/getnowcase/json?getalls=1"'
    output = subprocess.check_output(command, shell=True).decode('utf-8')

    # 将结果传递给 HTML 模板进行渲染
    app.config['ab_output'] = output

    # 每7秒自动运行一次
    t = Timer(3, run_ab_command)
    t.start()

@app.route('/')
def index():
    # 获取存储的 ab 命令输出结果
    ab_output = app.config.get('ab_output', '')

    # 将结果传递给 HTML 模板进行渲染
    return render_template('chart.html', ab_output=ab_output)

if __name__ == '__main__':
    # 启动定时器
    t = Timer(5, run_ab_command)
    t.start()

    # 运行 Flask 应用
    app.run()