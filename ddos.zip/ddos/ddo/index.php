<?php
$referer = 'https://gis.fdkc.gov.tw/';
$url = 'https://gis.fdkc.gov.tw/rescue/getnowcase/json?getalls=1&hr=48';

while (true) {
    $ch = curl_init();

    // Set the request URL and Referer header
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_REFERER, $referer);

    // Set curl options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);

    // Send the request
    $response = curl_exec($ch);

    // Check for errors
    if ($response === false) {
        echo 'Error: ' . curl_error($ch);
        exit;
    }

    // Get the response headers and body
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers = substr($response, 0, $headerSize);
    $body = substr($response, $headerSize);

    // Close the cURL resource
    curl_close($ch);

    // Decode the JSON response
    $data = json_decode($body, true);
                                                                                      // Filter the data for the past 10 minutes
    $filteredData = [];
    $currentTimestamp = time();
    $tenMinutesAgoTimestamp = $currentTimestamp - (10 * 20);

    foreach ($data['in_time'] as $index => $timestamp) {
        if ($timestamp >= $tenMinutesAgoTimestamp) {
            $filteredData[] = [
                'csno' => $data['csno'][$index],
                'dis_code' => $data['dis_code'][$index],
                'nt_name' => $data['nt_name'][$index],
                'nt_tel' => $data['nt_tel'][$index],
                'dept' => $data['dept'][$index],
                'cs_place' => $data['cs_place'][$index],
                'in_time' => $timestamp,
                'memo' => $data['memo'][$index]
            ];
        }
    }

    // Display the filtered data in the terminal
    foreach ($filteredData as $row) {
        echo "csno: " . $row['csno'] . "\n";
        echo "dis_code: " . $row['dis_code'] . "\n";
        echo "nt_name: " . $row['nt_name'] . "\n";
        echo "nt_tel: " . $row['nt_tel'] . "\n";
        echo "dept: " . $row['dept'] . "\n";
        echo "cs_place: " . $row['cs_place'] . "\n";
        echo "in_time: " . $row['in_time'] . "\n";
        echo "memo: " . $row['memo'] . "\n";
        echo "\n";
    }

    // Delay for 15 seconds before the next request
    sleep(15);
}

echo $response;
?>