from flask import Flask, jsonify
import requests
import codecs

app = Flask(__name__)

def convert_unicode_to_chinese(data):
    if isinstance(data, str):
        return codecs.escape_decode(data.encode('utf-8'))[0].decode('utf-8')
    elif isinstance(data, list):
        return [convert_unicode_to_chinese(item) for item in data]
    elif isinstance(data, dict):
        converted_data = {}
        for key, value in data.items():
            if key in ['memo', 'nt_tel', 'nt_name', 'dept', 'dis_code', 'in_time', 'cs_place']:
                converted_data[convert_unicode_to_chinese(key)] = convert_unicode_to_chinese(value)
            else:
                converted_data[key] = convert_unicode_to_chinese(value)
        return converted_data
    else:
        return data

@app.route("/")
def index():
    url = "https://gis.fdkc.gov.tw/rescue/getnowcase/json?getalls=1"
    headers = {
        'Referer': 'https://gis.fdkc.gov.tw/rescue/'
    }
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        return jsonify({"error": "请求数据失败"})
    json_data = response.json()
    converted_data = convert_unicode_to_chinese(json_data)
    return jsonify(converted_data)

if __name__ == "__main__":
    app.run(port=6100)