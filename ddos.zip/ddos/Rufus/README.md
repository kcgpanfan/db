-----

<p align="center">
<img src="https://repository-images.githubusercontent.com/465364428/50aa627e-8cb0-4970-afd9-51c81fe021f1", width="500", height="500">
</p>

-----

### <p align="center">🦎 Rufus 🦎</p>

<br><br>
<p align="center">
<strong>
Rufus is a simple but powerful Denial of Service tool written in Python3.
<br>
The type of the Dos attack is TCP Flood, the power of the attack will depend of your internet speed.
<br><br><br>
</strong>
<img src="https://cdn.discordapp.com/attachments/947619028715847700/948596915002556476/unknown.png" width="750", height="50">
</p>
<br>

-----

### <p align="center">⭐ Features ⭐</p>

<br><br>
<strong>+ Layer 4 attack</strong>
<br>
<strong>+ The only limit of the attack is your internet speed</strong>
<br>
<strong>+ You can choose the number of threads</strong>
<br>

<p align="right">
<img src="https://repository-images.githubusercontent.com/465364428/50aa627e-8cb0-4970-afd9-51c81fe021f1" width="250", height="250">
</p>

<br>
<strong>- No proxies will be used so the victim will see your IP Address</strong>
<br><br>

-----

### <p align="center">🎯 Levels 🎯</p>

<p align="center"><strong><i>This section shows the "levels" of this project, from 0/5 ⚪ to 5/5 ⚫!</i></strong</p>
<p align="center"><strong><i>⚪🟢🔵🔴🟣⚫</i></strong</p>

<br><br>
* Time: ⚪
* Complexity: 🟢
* Service: 🔴
<br><br>

-----

### <p align="center">💡 Ideas 💡</p>

<p align="center"><strong><i>Feel free to make a pull request on this repository to submit any idea!</i></strong</p>

<br><br>
* Add more attack modes (ex: SYN Flood, DNS Flood)
* Add a Layer 7 mode
<br><br>
 
-----

### <p align="center">📌 Disclaimer 📌</p>

<br><br>
* ***Please use this program only for educational purposes.***
* ***It is not meant to be used in any malicious way, and I decline any responsibility for what you do with it.***
<br><br>

-----

### <p align="center">billythegoat356</p>
