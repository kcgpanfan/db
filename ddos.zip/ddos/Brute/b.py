from colorama import init, Fore, Back, Style

# 初始化 colorama 库
init()

# 使用样式打印文本
print(Fore.GREEN + Back.BLACK + Style.BRIGHT + "Hello, World!")

# 使用预定义的样式
print(Fore.GREEN + "Operation successful!")
print(Fore.BLUE + "This is an informational message.")
print(Fore.YELLOW + "Warning: Something went wrong!")
print(Fore.RED + "Error: An error occurred!")