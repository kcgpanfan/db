import subprocess
from flask import Flask, render_template, request
from PIL import Image
import time
import random
import string

app = Flask(__name__)

def generate_filename(extension):
    timestamp = str(int(time.time()))
    random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    filename = f"processed_file_{timestamp}_{random_string}.{extension}"
    return filename

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return 'No file uploaded', 400

    file = request.files['file']
    quality = request.form.get('quality')

    if file.filename.endswith('.mp4'):
        # 保存上传的视频文件
        video_path = generate_filename('mp4')
        file.save(video_path)

        # 根据所选的画质选项进行视频处理
        if quality == 'low':
            output_path = generate_filename('mp4')
            # 使用FFmpeg命令进行低画质处理
            ffmpeg_command = f'ffmpeg -i {video_path} -vf scale=1280:570 {output_path}'
            subprocess.run(ffmpeg_command, shell=True)

        elif quality == 'high':
            output_path = generate_filename('mp4')
            # 使用FFmpeg命令进行高画质处理
            ffmpeg_command = f'ffmpeg -i {video_path} -vf scale=1920:1080 {output_path}'
            subprocess.run(ffmpeg_command, shell=True)

        return 'Video uploaded and processed successfully'

    elif file.filename.endswith(('.jpg', '.jpeg', '.png')):
        # 保存上传的图像文件
        image = Image.open(file.stream)

        # 进行图像处理，例如裁剪、高清化等
        # ...

        # 生成处理后的图像
        processed_image = image.resize((800, 600))  # 示例：调整图像大小为800x600

        # 保存处理后的图像
        output_path = generate_filename('jpg')
        processed_image.save(output_path)

        return 'Image uploaded and processed successfully'

    else:
        return 'Unsupported file format', 400

if __name__ == '__main__':
    app.run()