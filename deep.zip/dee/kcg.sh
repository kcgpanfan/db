#!/bin/bash

while true; do
    # 在每次循环开始之前等待20秒
    sleep 20

    # 执行ab命令
    ab -n 80000 -c 10000 -H "Referer: http://61.218.242.179:8080/tyfdapp/ServletApp?" "http://61.218.242.179:8080/tyfdapp/ServletApp\?data\=\78HbV6i6HSJ2j5FIFT01Hg\=\=\&cs_no\=\DOnm6cR8dbj9aq3rvVonGg\=\="
done
