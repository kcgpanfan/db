from flask import Flask, request, render_template, redirect, url_for
from lib.deepnoodlelib import *
from werkzeug.utils import secure_filename
import uuid
import os
from PIL import Image

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)

        file = request.files['file']

        if file.filename == '':
            return redirect(request.url)

        # Check if the file is an image and save it
        if allowed_file(file.filename):
            filename = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
            file.save(filename)
        else:
            return 'Unsupported file format. Please use a .jpg, .jpeg, or .png file for processing.'

        # Generate unique image_id and session_id
        image_id = generate_random_token(TOKLEN_IMGID)
        session_id = generate_random_token(TOKLEN_SESSIONID)

        # Legalize upload token
        get_upload_perm(image_id, session_id)

        # Upload image and process
        status = upload_image(image_id, session_id, filename)

        if status != 200:
            return 'Image processing failed. Please try again.'

        # Get the processed image
        data = get_image(image_id, session_id)

        if data[0] != 200:
            return 'Image download failed. Please try again.'

        random_image_name = str(uuid.uuid1()) + '.jpg'
        result_filename = os.path.join('static', random_image_name)

        with open(result_filename, 'wb') as f:
            f.write(data[1])

        # Resize the image to 1000 width and 700 height
        resized_image = resize_image(result_filename, 1375, 970)
        resized_image.save(result_filename)

        return render_template('i8.html', result_filename=result_filename)

    return render_template('i8.html', result_filename=None)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'jpg', 'jpeg', 'png'}

def resize_image(image_path, width, height):
    img = Image.open(image_path)
    resized_img = img.resize((width, height), Image.LANCZOS)
    return resized_img

if __name__ == '__main__':
    app.run(port=6600)
