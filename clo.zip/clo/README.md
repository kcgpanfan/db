
<p align="center">
<a href="https://is.gd/UQreTd"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>
<p>
<a href="https://img.shields.io/badge/PRINCE-KUMAR-green" ><img  src="https://img.shields.io/badge/PRINCE-KUMAR-green"></a>  <a href="#" ><img  src="https://img.shields.io/badge/cloud-red"></a>  <a href="#"><img src="https://img.shields.io/badge/MADE%20IN%20-BASH-yellow"></a></p>
 
 ```
note : this tool is using cloudflare in the background of the script 
```
## Tasted on 
1. Kali linux 
2. ubantu 
3. termux 
4. garuda linux 
 ## Termux Installation 
 *`apt update && apt upgrade`

*`pkg install git` 

*`git clone https://github.com/princekrvert/cloud.git`

*`cd cloud`

*`chmod +x cloud.sh`

*`./cloud.sh `
 
### social links 
 <a href="https://www.instagram.com/princekrvert/"> <img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"></a>
<a href="https://m.twitter.com/princekrvert" > <img src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white"> </a>
<a href="https://www.youtube.com/channel/UCiplAqC9AwtGGxXU3WQy8pw"><img src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white"></a>
<a href="https://www.facebook.com/princekrvert" > <img src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" ></a>

